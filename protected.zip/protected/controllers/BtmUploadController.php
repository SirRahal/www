<?php
/**
 * Created by PhpStorm.
 * User: Sari
 * Date: 1/14/15
 * Time: 2:36 PM
 */

class BtmuploadController extends Controller
{

    /**
     *
     */
    public function actionIndex()
    {
        $this->render('upload');
    }

}