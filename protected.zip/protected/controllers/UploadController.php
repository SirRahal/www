<?php
/**
 * Created by PhpStorm.
 * User: Sari
 * Date: 12/10/14
 * Time: 4:05 PM
 */

class UploadController extends Controller
{

    /**
     *
     */
    public function actionIndex()
    {
        $this->render('upload');
    }

}