<?php
/* @var $this BtmlistingsController */
/* @var $model Btmlistings */

$this->breadcrumbs=array(
	'Btm Listings'=>array('index'),
	'Create',
);


?>

<h1>Create Btmlistings</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>