<?php
/* @var $this BtmimagesController */
/* @var $model Btmimages */

$this->breadcrumbs=array(
	'Btm Images'=>array('index'),
	'Create',
);

?>

<h1>Create Btm Images</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>