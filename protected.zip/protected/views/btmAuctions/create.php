<?php
/* @var $this BtmAuctionsController */
/* @var $model BtmAuctions */

$this->breadcrumbs=array(
	'Btm Auctions'=>array('index'),
	'Create',
);


?>

<h1>Create BtmAuctions</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>