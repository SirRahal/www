<?php
/* @var $this BtmauctionController */
/* @var $model Btmauction */

$this->breadcrumbs=array(
	'Btm Auctions'=>array('index'),
	'Create',
);


?>

<h1>Create Btmauction</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>