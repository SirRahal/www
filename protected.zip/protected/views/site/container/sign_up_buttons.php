<style>

</style>
<div style=" height: 130px;   float: right; padding: 10px; margin-right: -30px; z-index: 100; margin-top: -50px;">
    <div style="padding:10px; height: 110px; box-shadow: 0 0 7px 5px #000000; text-align: center;">
        <h3>Sign-up to get IT each month!</h3>
        <!-- Add an optional button to open the popup -->
        <button style="width:197px;" onclick="location.href='/index.php/customers/create'">Sign-up Free Internet Copy</button>
        <button style="width:197px;" onclick="location.href='/index.php/customersHardcopy/create'">Sign-up Hard Copy $1.67/m</button>
        <!--<button class="newssignup_open button slidein-open" style="width:197px;">Sign-up Free Internet Copy</button>
        <button class="newssignup_hardcopy_open button slidein-open" style="width:197px;">Sign-up Hard Copy $1.67/m</button>-->
    </div>
</div>