﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page6", "num":"10-11"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"28.74 MB"}}
    
      ,{"PdfPage":{"url":"page0006.pdf", "size":"1.08 MB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0006.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"8-9","src":"page5.html"},
    
    "rightTool":{"innerText":" 12-13","src":"page7.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	