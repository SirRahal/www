﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page9", "num":"16-17"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"28.74 MB"}}
    
      ,{"PdfPage":{"url":"page0009.pdf", "size":"1.30 MB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0009.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"14-15","src":"page8.html"},
    
    "rightTool":{"innerText":" 18-19","src":"page10.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	