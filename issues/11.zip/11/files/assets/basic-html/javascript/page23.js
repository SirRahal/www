﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page23", "num":"44"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 720",
    "isWide":"False",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"28.74 MB"}}
    
      ,{"PdfPage":{"url":"page0023.pdf", "size":"711.65 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0023.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"42-43","src":"page22.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	