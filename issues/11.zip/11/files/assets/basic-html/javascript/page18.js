﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page18", "num":"34-35"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"28.74 MB"}}
    
      ,{"PdfPage":{"url":"page0018.pdf", "size":"1.51 MB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0018.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"32-33","src":"page17.html"},
    
    "rightTool":{"innerText":" 36-37","src":"page19.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	