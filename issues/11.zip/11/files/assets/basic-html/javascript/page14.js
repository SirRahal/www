﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page14", "num":"26-27"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"28.74 MB"}}
    
      ,{"PdfPage":{"url":"page0014.pdf", "size":"1.17 MB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0014.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"24-25","src":"page13.html"},
    
    "rightTool":{"innerText":" 28-29","src":"page15.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	