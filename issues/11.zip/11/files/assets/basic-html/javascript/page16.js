﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page16", "num":"30-31"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"28.74 MB"}}
    
      ,{"PdfPage":{"url":"page0016.pdf", "size":"1.12 MB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0016.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"28-29","src":"page15.html"},
    
    "rightTool":{"innerText":" 32-33","src":"page17.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	