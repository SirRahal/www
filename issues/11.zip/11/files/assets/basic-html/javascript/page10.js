﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page10", "num":"18-19"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"28.74 MB"}}
    
      ,{"PdfPage":{"url":"page0010.pdf", "size":"1.62 MB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0010.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"16-17","src":"page9.html"},
    
    "rightTool":{"innerText":" 20-21","src":"page11.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	