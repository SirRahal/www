﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page7", "num":"12-13"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"28.74 MB"}}
    
      ,{"PdfPage":{"url":"page0007.pdf", "size":"1.24 MB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0007.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"10-11","src":"page6.html"},
    
    "rightTool":{"innerText":" 14-15","src":"page8.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	