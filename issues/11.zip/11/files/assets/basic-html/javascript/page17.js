﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page17", "num":"32-33"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"28.74 MB"}}
    
      ,{"PdfPage":{"url":"page0017.pdf", "size":"861.84 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0017.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"30-31","src":"page16.html"},
    
    "rightTool":{"innerText":" 34-35","src":"page18.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	