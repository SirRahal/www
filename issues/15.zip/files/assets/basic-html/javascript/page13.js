﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page13", "num":"24-25"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"6.09 MB"}}
    
      ,{"PdfPage":{"url":"page0013.pdf", "size":"277.67 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0013.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"22-23","src":"page12.html"},
    
    "rightTool":{"innerText":" 26-27","src":"page14.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	