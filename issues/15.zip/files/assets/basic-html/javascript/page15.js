﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page15", "num":"28-29"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"6.09 MB"}}
    
      ,{"PdfPage":{"url":"page0015.pdf", "size":"312.16 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0015.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"26-27","src":"page14.html"},
    
    "rightTool":{"innerText":" 30-31","src":"page16.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	