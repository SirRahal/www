﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page1", "num":"1"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 720",
    "isWide":"False",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"6.09 MB"}}
    
      ,{"PdfPage":{"url":"page0001.pdf", "size":"187.51 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0001.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"","src":"toc.html"},
    
    "rightTool":{"innerText":" 2-3","src":"page2.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	