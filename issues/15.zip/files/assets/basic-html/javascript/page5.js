﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page5", "num":"8-9"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"6.09 MB"}}
    
      ,{"PdfPage":{"url":"page0005.pdf", "size":"272.33 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0005.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"6-7","src":"page4.html"},
    
    "rightTool":{"innerText":" 10-11","src":"page6.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	