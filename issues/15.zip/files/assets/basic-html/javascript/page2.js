﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page2", "num":"2-3"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"792",
    "width":" 1440",
    "isWide":"True",
    "bookWidth":"720",
    "bookHeight":"792",

    "download":[{}
      ,{"pdfPublication":{"url":"publication.pdf", "size":"6.09 MB"}}
    
      ,{"PdfPage":{"url":"page0002.pdf", "size":"287.73 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0002.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"1","src":"page1.html"},
    
    "rightTool":{"innerText":" 4-5","src":"page3.html"},
    
    "cart":[{}
    
    ],
    "content":[{}
        
    ]
})
 	